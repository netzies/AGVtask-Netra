"""
Homework 5
Submission Functions
"""
import numpy as np
import cv2
from scipy.spatial.distance import cdist
data = np.load(r"data\some_corresp.npz")
import helper
im1 = cv2.imread(r"data\im1.png")
im2 = cv2.imread(r"data\im2.png")
intrinsics = np.load(r"data\intrinsics.npz")
from numpy.linalg import qr


"""
Q3.1.1 Eight Point Algorithm
       [I] pts1, points in image 1 (Nx2 matrix)
           pts2, points in image 2 (Nx2 matrix)
           M, scalar value computed as max(H1,W1)
       [O] F, the fundamental matrix (3x3 matrix)
       
"""
def eight_point(pts1, pts2, M):
    # we scale the input points using a Transformation matrix
    matrix = np.array([[1/M , 0 , 0],[0 , 1/M , 0],[0 , 0, 1]])
    ones = np.ones((pts1.shape[0]))
    #homogenizing the points
    pts1h = np.column_stack((pts1, ones))
    pts2h = np.column_stack((pts2, ones))
    #scaling the matrix 
    pts1n = (matrix @ pts1h.T).T
    pts2n = (matrix @ pts2h.T).T
    #constructing A
    A = np.zeros((pts1.shape[0],9))
    for i in range(pts1.shape[0]):
        A[i] = [pts1n[i][0]*pts2n[i][0], pts1n[i][0]*pts2n[i][1] ,pts1n[i][0],pts1n[i][1]*pts2n[i][0],pts1n[i][1]*pts2n[i][1],pts1n[i][1],pts2n[i][0],pts2n[i][1],1]
    # Perform SVD
    U, S, Vt = np.linalg.svd(A)
    F_vector = Vt[-1]  # Last row of Vt (which is the last column of V)
    F = F_vector.reshape(3, 3)
    U1, S1, V1 = np.linalg.svd(F)
    S1_ = np.diag(S1)
    S1_[2, 2] = 0
    F_new = U1 @ S1_ @ V1
    F_refined = helper.refineF(F_new, pts1n[:,:2], pts2n[:,:2])  # Provided in helper.py
    F_final = matrix.T @ F_refined @ matrix
    return F_final
    
    




"""
Q3.1.2 Epipolar Correspondences
       [I] im1, image 1 (H1xW1 matrix)
           im2, image 2 (H2xW2 matrix)
           F, fundamental matrix from image 1 to image 2 (3x3 matrix)
           pts1, points in image 1 (Nx2 matrix)
       [O] pts2, points in image 2 (Nx2 matrix)
"""
def epipolar_correspondences(im1, im2, F, pts1):
# replace pass by your implementation
    pts2 = np.zeros_like(pts1)
    ones = np.ones((pts1.shape[0]))
    pts1 = np.column_stack((pts1,ones))
    half_w = 15
    lines = (F @ pts1.T).T
    for i in range(len(pts1)):
        min_dist = float("inf")
        window = im1[int(pts1[i][1] - half_w) : int(pts1[i][1] + half_w + 1),int(pts1[i][0] - half_w) : int(pts1[i][0] + half_w + 1)]
        for x in range(int(pts1[i][0]) - 30, int(pts1[i][0]) + 30):
            y = int((-lines[i][2] -lines[i][0]*x) / lines[i][1])

            window1 = im2[y - half_w : y + half_w + 1, x - half_w : x + half_w + 1]
            dist = np.sum(np.square(window-window1))
            if dist < min_dist:
                min_dist = dist
                pts2[i] = [x, y]
    return pts2



"""
Q3.1.3 Essential Matrix
       [I] F, the fundamental matrix (3x3 matrix)
           K1, camera matrix 1 (3x3 matrix)
           K2, camera matrix 2 (3x3 matrix)
       [O] E, the essential matrix (3x3 matrix)
"""
def essential_matrix(F, K1, K2):
    E = K2.T @ F @ K1
    return E 


"""
Q3.1.4 Triangulation
       [I] P1, camera projection matrix 1 (3x4 matrix)
           pts1, points in image 1 (Nx2 matrix)
           P2, camera projection matrix 2 (3x4 matrix)
           pts2, points in image 2 (Nx2 matrix)
       [O] pts3d, 3D points in space (Nx3 matrix)
"""
def triangulate(P1, pts1, P2, pts2):
    """
    Triangulates 3D points from two sets of 2D correspondences.

    Parameters:
        P1 (numpy.ndarray): 3x4 Camera projection matrix for image 1.
        pts1 (numpy.ndarray): Nx2 Array of 2D points in image 1.
        P2 (numpy.ndarray): 3x4 Camera projection matrix for image 2.
        pts2 (numpy.ndarray): Nx2 Array of 2D points in image 2.

    Returns:
        numpy.ndarray: Nx3 Array of triangulated 3D points.
    """
    num_points = pts1.shape[0]
    pts3d = np.zeros((num_points, 3))  # Store triangulated 3D points
    ones = np.ones((pts1.shape[0],))
    pts1n = np.column_stack((pts1, ones))
    pts2n = np.column_stack((pts2, ones))

    for i in range(num_points):
        x1, y1 = pts1[i]  # Image 1 coordinates
        x2, y2 = pts2[i]  # Image 2 coordinates
        

        # Construct the matrix A for AX = 0
        A = np.array([
            x1 * P1[2] - P1[0],  # u * P1[2] - P1[0]
            y1 * P1[2] - P1[1],  # v * P1[2] - P1[1]
            x2 * P2[2] - P2[0],  # u' * P2[2] - P2[0]
            y2 * P2[2] - P2[1]   # v' * P2[2] - P2[1]
        ])

        # Solve for X using SVD
        _, _, VT = np.linalg.svd(A)
        X = VT[-1]  # Take the last row of VT

        # Convert from homogeneous to Cartesian coordinates
        if abs(X[3]) > 1e-6:  # Avoid division by zero
            X /= X[3]
        else:
            X = [0, 0, 0, 0]

        # Store the 3D point
        pts3d[i] = X[:3]

    return pts3d



"""
Q3.2.1 Image Rectification
       [I] K1 K2, camera matrices (3x3 matrix)
           R1 R2, rotation matrices (3x3 matrix)
           t1 t2, translation vectors (3x1 matrix)
       [O] M1 M2, rectification matrices (3x3 matrix)
           K1p K2p, rectified camera matrices (3x3 matrix)
           R1p R2p, rectified rotation matrices (3x3 matrix)
           t1p t2p, rectified translation vectors (3x1 matrix)
"""
def rectify_pair(K1, K2, R1, R2, t1, t2):
    # replace pass by your implementation
    C1 = -np.linalg.inv(K1@R1) @ (K1 @ t1)
    C2 = -np.linalg.inv(K2@R2) @ (K2 @ t2)
   
    r1 = (C1 - C2)/ np.linalg.norm(C1 - C2)
    r2 = np.cross(R1[2,:].T,r1)
    r3 = np.cross(r2,r1)
    R1p = R2p = np.vstack((r1,r2,r3))
    K2p = K1p = K2 
    t1p = -(R1p) @ C1
    t2p = -(R2p) @ C2
    M1 = (K1p @ R1p) @ (np.linalg.inv(K1 @ R1))
    M2 = (K2p @ R2p) @ (np.linalg.inv(K2 @ R2))
    return M1, M2, K1p, K2p, R1p, R2p, t1p, t2p



"""
Q3.2.2 Disparity Map
       [I] im1, image 1 (H1xW1 matrix)
           im2, image 2 (H2xW2 matrix)
           max_disp, scalar maximum disparity value
           win_size, scalar window size value
       [O] dispM, disparity map (H1xW1 matrix)
"""
def get_disparity(im1, im2, max_disp, win_size):
    # replace pass by your implementation
    w = (win_size - 1) // 2
    disparitymap = np.zeros_like(im1)
    for j in range(w + max_disp,im1.shape[0]-w): # loops through all values of y vertically searching along lines
        for i in range(w + max_disp,im1.shape[1]-w):
            ssd_out= np.inf
         # loops through all values of x horizontally searching through lines
            disp = -1
            window1=im1[j-w : j+w+1, i-w : i+w+1]
            for d in range(max_disp): #range of window
                
                window2 = im2[j-w : j+w+1, i-w-d : i+w+1-d]
                ssd = np.sum((window1 - window2) ** 2)
                if ( ssd < ssd_out):
                    ssd_out = ssd
                    disp = d

            disparitymap[j][i] = disp
    return disparitymap 

"""
Q3.2.3 Depth Map
       [I] dispM, disparity map (H1xW1 matrix)
           K1 K2, camera matrices (3x3 matrix)
           R1 R2, rotation matrices (3x3 matrix)
           t1 t2, translation vectors (3x1 matrix)
       [O] depthM, depth map (H1xW1 matrix)
"""

def get_depth(dispM, K1, K2, R1, R2, t1, t2):
    """
    Computes the depth map from the disparity map.

    Args:
        dispM (numpy.ndarray): Disparity map (H x W).
        K1 (numpy.ndarray): Intrinsic matrix of the left camera.
        K2 (numpy.ndarray): Intrinsic matrix of the right camera.
        R1 (numpy.ndarray): Rotation matrix of the left camera.
        R2 (numpy.ndarray): Rotation matrix of the right camera.
        t1 (numpy.ndarray): Translation vector of the left camera.
        t2 (numpy.ndarray): Translation vector of the right camera.

    Returns:
        numpy.ndarray: Depth map (H x W).
    """

    # Compute optical centers C1 and C2
    C1 = -np.linalg.inv(K1 @ R1) @ (K1 @ t1)
    C2 = -np.linalg.inv(K2 @ R2) @ (K2 @ t2)

    # Compute baseline b = ||C1 - C2||
    baseline = np.linalg.norm(C1 - C2)

    # Extract focal length f = K1(1,1) (first entry of K1)
    focal_length = K1[0, 0]

    # Initialize depth map with zeros
    depthM = np.zeros_like(dispM, dtype=np.float32)

    # Compute depth only for nonzero disparity values
    valid_disp = dispM > 0  # Avoid division by zero
    depthM[valid_disp] = (baseline * focal_length) / dispM[valid_disp]

    return depthM


  


"""
Q3.3.1 Camera Matrix Estimation
       [I] x, 2D points (Nx2 matrix)
           X, 3D points (Nx3 matrix)
       [O] P, camera matrix (3x4 matrix)
"""
def estimate_pose(x, X):
    # replace pass by your implementation
    pass


"""
Q3.3.2 Camera Parameter Estimation
       [I] P, camera matrix (3x4 matrix)
       [O] K, camera intrinsics (3x3 matrix)
           R, camera extrinsics rotation (3x3 matrix)
           t, camera extrinsics translation (3x1 matrix)
"""
def estimate_params(P):
    def rq(A):
        Q, R = qr(np.flipud(A).T)
        R = np.flipud(R.T)
        Q = Q.T
        return Q[:, ::-1], R[::-1, :]
    # replace pass by your implementation
    M = P[:, :3] 
    K, R = rq(M)
 # Extract translation vector t

    t = np.linalg.inv(K) @ P[:, -1]

    return K, R, t

   





import numpy as np
import helper as hlp
import skimage.io as io
from submission import *
import matplotlib.pyplot as plt


cpoints = np.load(r"data\some_corresp.npz")
im1 = io.imread(r"data\im1.png")
im2 = io.imread(r"data\im2.png")

intrinsics = np.load(r"data\intrinsics.npz")
K1 = intrinsics['K1']
K2 = intrinsics['K2']

pts1 = cpoints['pts1']
pts2 = cpoints['pts2']
F = eight_point(pts1, pts2, max(im1.shape))

E = essential_matrix(F, intrinsics["K2"], intrinsics["K1"])

P1 = K1 @ np.hstack([np.eye(3), np.zeros((3, 1))])

plot_pts = np.load(r'data\temple_coords.npz')
pts1_img = plot_pts['pts1']

pts2_img = epipolar_correspondences(im1, im2, F, pts1_img)

M2S = helper.camera2(E)
results = np.zeros((4, pts1_img.shape[0], 3))
max_valid = -1
best_index = -1
for i in range(4) :
    P2 = K2 @ M2S[:,:,i]
    res = triangulate(P1, pts1_img, P2, pts2_img)
    results[i] = res
    if(np.sum(res[:, -1] > 0) > max_valid):
        best_index = i
        max_valid = np.sum(res[:, -1] > 0)

P2 = K2 @ M2S[:,:,best_index]
res = results[best_index]


# Compute reprojection error 
ones = np.ones((res.shape[0], 1))
res_hom = np.hstack((res, ones))  # Convert to homogeneous coordinates
# Project 3D points back to 2D using P1
proj_pts = (P1 @ res_hom.T).T  # Nx3
proj_pts_2D = proj_pts[:, :2] / proj_pts[:, 2, np.newaxis]  # Convert to 2D
errors = np.linalg.norm(proj_pts_2D - pts1_img, axis=1)
reprojection_error = np.mean(errors)
print(f"Mean Reprojection Error: {reprojection_error:.4f} pixels")

#  Scatter plot the correct 3D points
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(res[:,0], res[:, 1], res[:, 2], s=3, c='b')
plt.show()
#  Save the computed extrinsic parameters (R1,R2,t1,t2) to data/extrinsics.npz
K1,R1,t1 = estimate_params(P1)
K2,R2,t2 = estimate_params(P2)
np.savez(r"data\extrinsics", R1=R1, t1=t1, R2=-R2, t2=t2)


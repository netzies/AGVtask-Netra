import numpy as np
import cv2 as cv
import helper
import submission as sub
data = np.load("data/some_corresp.npz")
im1 = cv.imread(r'data\im1.png')
im2 = cv.imread(r'data\im2.png')
pts1 = data['pts1']
pts2 = data['pts2']

M = int(max(im1.shape[0], im1.shape[1]))
F = sub.eight_point(pts1, pts2, M)
print(F)
#helper.displayEpipolarF(im1, im2, F)

helper.epipolarMatchGUI(im1, im2, F)